/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hotelmanagementsystemkb;
import java.sql.*;
/**
 *
 * @author kisho
 */
public class connection {
 Connection c;
    Statement s;
    public connection(){
        
        
        try{
          Class.forName("com.mysql.cj.jdbc.Driver");
          String url = "jdbc:mysql://localhost:3306/mydatabase";
          c = DriverManager.getConnection(url,"root","");
          s = c.createStatement();
          System.out.println("connected Success");
        }
        catch(Exception e){
        e.printStackTrace();
        System.out.println("Exception");
        }
    }
            
      
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
         new connection();
    }
}
